sudo add-apt-repository ppa:longsleep/golang-backports -y
sudo apt update
sudo apt install golang-go -y
go build
mv hello sg
nvcc -o mine/cmine mine/mine.cu
