while true; do
	./sg mining start -c c
    	sleep 60 
done
