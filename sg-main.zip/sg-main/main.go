package main

import (
	. "hello/pkg/program"
)

func main() {
	RunNetworkCMD().Execute()
}
